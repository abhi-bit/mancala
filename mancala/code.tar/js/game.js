var me = -1;
var gs;
$(document).ready(function() {
    setupJars();
    setupEventHandlers();
    var qs = location.search.replace(/\?/g, '');
    $.ajax({
        url: 'http://mankala.zc2.zynga.com/api/initGame.php',
        data: qs,
        success: function(result) {
            console.log(result);
            gs = JSON.parse(result);        
            console.log("Game State JSON = " + gs);
            initBoard(qs,gs);
	// setup a ugly poller
            setInterval(function() {$.ajax({
                url: 'http://mankala.zc2.zynga.com/api/getState.php',
                data: {s: gs.session_id},
                success: function(result) {
                    // find the game state from server
                        gs = JSON.parse(result);
                        if (me != -1 && (gs.active_player == me)) {
                            renderBoard(gs);
                            console.log("rendering board via setInterval");
                        }
                    },
                })}, 3000);
        }
    });

});

function setupEventHandlers() {
    $('.grid_2').click(function(e) {
        e.preventDefault();
        console.log($(this).attr('id'));
        if (gs.active_player == -1) {
            console.log("Please wait, game not yet ready");
            return;
        }
        if (gs.active_player != me) {
            console.log("Sorry, not your turn");
            return;
        }
        board_pos = $(this).attr('id').split('_')[1];
        if (me == 1 && (board_pos > 5 && board_pos < 12)) {
            // ajax request
            $.ajax({
                url: 'http://mankala.zc2.zynga.com/api/move.php',
                data: {s: gs.session_id, box: board_pos},
                success: function(result) {
                    gs = JSON.parse(result);
                    renderBoard(gs);
                }
            });
            return;
        }
        if (me == 0 && (board_pos >= 0 && board_pos < 6)) {
            // ajax request
            $.ajax({
                url: 'http://mankala.zc2.zynga.com/api/move.php',
                data: {s: gs.session_id, box: board_pos},
                success: function(result) {
                    gs = JSON.parse(result);
                    renderBoard(gs);
                }
            });

            return;
        }
        console.log("invalid move by player");
    });
}
/* result: GameStatus 
   displays GameBoard and updates Player information */

function setupJars() {
    var top = $('.container_12').offset().top;
    var left = $('.container_12').offset().left;
    var right = $('.container_12').width() + left;

    $('.jar_1').css({
        top: top,
        left: left - 150,
        position: 'fixed',
    });

    $('.jar_0').css({
        top: top,
        left: right,
        position: 'fixed'
    });
}

function renderBoard(result) {
    var board = result.board;
    var obj;
    for (i = 0; i < board.length; ++i) {
        obj = '#board_' + i;
        $(obj).find('p').html(board[i]);
    }
    if (gs.num_players == 2 && ($('#url').css('visibility') == "visible"))
        $('#url').css('visibility', 'hidden');
    $('#status').html('Player ' + gs.active_player + ' Turn');
}

function initBoard(qs, result) {
    me = result.num_players - 1;
    $('#player').val(me);
    var game_url = $('#url');
    console.log(typeof(result));
    if (qs) {
        $(game_url).html(location.href);
    } else {
        $(game_url).html(location.href + '?s=' + result.session_id);
    }
    renderBoard(result);
    // hide the URL if all players are in
    if (result.num_players == 2) {
        $('#url').css('visibility', 'hidden');
        $('#status').html('Player ' + result.active_player + ' Turn')
    // Update whose turn is next
    } else {
        $('#status').html('Waiting for peers to join');
    }
}

